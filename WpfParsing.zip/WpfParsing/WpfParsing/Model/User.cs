﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace WpfParsing.Model
{
    public class User
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public DateTime BornDate { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }



        public User()
        {
            FirstName = string.Empty;
            MiddleName = string.Empty;
            LastName = string.Empty;
            Login = string.Empty;
            Password = string.Empty;
            
        }

        public User (int id, string firstname, string middlename, string lastname, string login, string password)
        { 
            FirstName = firstname;
            MiddleName = middlename;
            LastName = lastname;
            Login = login;
            Password = password;

        }

        public override string ToString()
        {
            return $"{Id} {FirstName} {MiddleName} {LastName} \n{Login} {Password}";
        }
    }
}
