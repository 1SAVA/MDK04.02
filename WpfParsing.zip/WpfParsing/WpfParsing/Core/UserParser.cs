﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfParsing.Model;
using System.IO;

namespace WpfParsing.Core
{
    internal class UserParser
    {
        public static IEnumerable<User> Parse(string path)

        {
            foreach (var line in File.ReadAllLines(path).Skip(1))
            {
                string[] props = line.Split(';');
                yield return new User(Convert.ToInt32(props[0]),
                    props[1], props[2], props[3],
                    props[4],
                    props[5]);
            }
        }

    }
}
