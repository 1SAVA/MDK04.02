﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfParsing.Core
{
    internal static class UserValidators
    {
        public static bool Validate(string login, string password)
        {
            if (login == "admin" && password == "admin")
                return true;

            return false;
        }
    }
}
